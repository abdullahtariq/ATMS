<?php

// echo "This is our HM Dashboard";

?>

<h2>This is our HM Dashboard</h2>